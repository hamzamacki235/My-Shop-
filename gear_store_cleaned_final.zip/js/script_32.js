
function exportLogToCSV() {
  firebase.firestore().collection("activity_log").orderBy("timestamp", "desc").limit(100).get().then(snapshot => {
    let csvContent = "data:text/csv;charset=utf-8,Time,User ID,Message\n";

    snapshot.forEach(doc => {
      const data = doc.data();
      const time = data.timestamp?.toDate().toLocaleString() || "بدون وقت";
      const userId = data.userId || "مجهول";
      const message = data.message || "";
      csvContent += `"${time}","${userId}","${message}"\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "activity_log.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });
}
