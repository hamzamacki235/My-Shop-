
document.addEventListener("DOMContentLoaded", () => {
  const links = document.querySelectorAll('a[href^="#"]');
  const sections = document.querySelectorAll("section");

  function showSection(id) {
    sections.forEach(section => {
      section.style.display = (section.id === id) ? "block" : "none";
    });
  }

  links.forEach(link => {
    link.addEventListener("click", e => {
      const id = link.getAttribute("href").substring(1);
      if (id) {
        e.preventDefault();
        showSection(id);
      }
    });
  });

  showSection("products");
});
