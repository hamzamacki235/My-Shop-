
function addProduct() {
  const name = document.getElementById("name").value;
  const desc = document.getElementById("desc").value;
  const price = document.getElementById("price").value;
  const imageFile = document.getElementById("image").files[0];

  const user = firebase.auth().currentUser;

  if (!user) {
    alert("يجب تسجيل الدخول لإضافة منتج.");
    return;
  }

  if (!imageFile) {
    alert("الرجاء اختيار صورة للمنتج.");
    return;
  }

  const storageRef = firebase.storage().ref('product_images/' + Date.now() + '_' + imageFile.name);
  storageRef.put(imageFile).then(snapshot => snapshot.ref.getDownloadURL())
    .then(url => {
      return firebase.firestore().collection("products").add({
        name,
        desc,
        price: parseFloat(price),
        image: url,
        timestamp: firebase.firestore.FieldValue.serverTimestamp(),
        userId: user.uid,
        userEmail: user.email
      });
    })
    .then(() => {
      alert("تم حفظ المنتج بنجاح");
      document.getElementById("name").value = "";
      document.getElementById("desc").value = "";
      document.getElementById("price").value = "";
      document.getElementById("image").value = "";
    })
    .catch(error => {
      alert("فشل في إضافة المنتج: " + error.message);
      console.error(error);
    });
}
