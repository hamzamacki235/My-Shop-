
function applySavedSettings() {
  const lang = localStorage.getItem("lang") || "ar";
  const dark = localStorage.getItem("dark") === "true";

  isArabic = lang === "ar";
  document.body.dir = isArabic ? "rtl" : "ltr";
  document.querySelectorAll('[data-ar]').forEach(el => {
    el.innerText = isArabic ? el.dataset.ar : el.dataset.en;
  });

  if (dark) {
    document.body.classList.add("dark-mode");
  }
}

function toggleLang() {
  isArabic = !isArabic;
  document.body.dir = isArabic ? "rtl" : "ltr";
  document.querySelectorAll('[data-ar]').forEach(el => {
    el.innerText = isArabic ? el.dataset.ar : el.dataset.en;
  });
  localStorage.setItem("lang", isArabic ? "ar" : "en");
}

function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
  localStorage.setItem("dark", document.body.classList.contains("dark-mode"));
}

function resetSettings() {
  document.body.classList.remove("dark-mode");
  isArabic = true;
  document.body.dir = "rtl";
  document.querySelectorAll('[data-ar]').forEach(el => {
    el.innerText = el.dataset.ar;
  });
  localStorage.removeItem("lang");
  localStorage.removeItem("dark");
}

document.addEventListener("DOMContentLoaded", applySavedSettings);
