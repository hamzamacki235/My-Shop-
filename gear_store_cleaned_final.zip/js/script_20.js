
document.addEventListener("DOMContentLoaded", () => {
  const indexContainer = document.getElementById("new-products");
  if (indexContainer) {
    indexContainer.innerHTML = "<p>...جاري تحميل المنتجات</p>";
    firebase.firestore().collection("products").orderBy("timestamp", "desc").limit(5).get().then(snapshot => {
      indexContainer.innerHTML = "";
      snapshot.forEach(doc => {
        const p = doc.data();
        const card = document.createElement("div");
        card.className = "product";
        card.innerHTML = `
          ${p.image ? '<img src="' + p.image + '" style="max-width:100px;"><br>' : ''}
          <strong>${p.name}</strong><br>${p.desc}<br>السعر: ${p.price} ريال
        `;
        indexContainer.appendChild(card);
      });
    }).catch(err => {
      indexContainer.innerHTML = "<p>تعذر تحميل المنتجات</p>";
      console.error(err);
    });
  }
});
