
let isArabic = true;

function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
}

function toggleLang() {
  isArabic = !isArabic;
  document.body.dir = isArabic ? "rtl" : "ltr";
  document.querySelectorAll('[data-ar]').forEach(el => {
    el.innerText = isArabic ? el.dataset.ar : el.dataset.en;
  });
}
