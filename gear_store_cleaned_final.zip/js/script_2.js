
    function toggleDarkMode() {
      document.body.classList.toggle("dark-mode");
      localStorage.setItem("darkMode", document.body.classList.contains("dark-mode"));
    }
    
    function openModal(id) {
      document.getElementById(id).style.display = "flex";
      document.body.style.overflow = "hidden";
    }
    
    function closeModal(id) {
      document.getElementById(id).style.display = "none";
      document.body.style.overflow = "auto";
    }
    
    window.onclick = function(e) {
      ["loginModal", "registerModal", "ratingModal"].forEach(id => {
        const m = document.getElementById(id);
        if (e.target === m) closeModal(id);
      });
    };
    
    // تحميل وضع الوضع الليلي من التخزين المحلي
    if (localStorage.getItem("darkMode") === "true") {
      document.body.classList.add("dark-mode");
    }
    
    // وظيفة الأسئلة الشائعة
    window.toggleFaq = function(element) {
      const answer = element.nextElementSibling;
      const icon = element.querySelector('.faq-icon');
      
      answer.classList.toggle('show');
      icon.textContent = answer.classList.contains('show') ? '-' : '+';
    };
  