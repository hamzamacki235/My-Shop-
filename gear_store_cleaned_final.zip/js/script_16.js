
document.addEventListener("DOMContentLoaded", () => {
  const paymentsLink = document.querySelector('a[href="#payments"]');
  if (paymentsLink) {
    paymentsLink.addEventListener("click", () => {
      const tbody = document.getElementById("payment-records");
      tbody.innerHTML = "";
      firebase.firestore().collection("payments").orderBy("createdAt", "desc").get().then(snapshot => {
        snapshot.forEach(doc => {
          const p = doc.data();
          const tr = document.createElement("tr");
          tr.innerHTML = `
            <td>${p.name}</td>
            <td>${p.card}</td>
            <td>${p.notify}</td>
            <td>${p.createdAt ? new Date(p.createdAt.toDate()).toLocaleString() : ""}</td>
          `;
          tbody.appendChild(tr);
        });
      });
    });
  }
});
