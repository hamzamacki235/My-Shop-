
  function scrollToCloudLog() {
    const el = document.getElementById("cloud-activity-log");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  }
