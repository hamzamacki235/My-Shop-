
  document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.querySelector('#login form');
    if (loginForm) {
      loginForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const email = loginForm.querySelector('input[type="email"]').value.trim();
        const password = loginForm.querySelector('input[type="password"]').value;

        if (!email || !password) {
          alert("يرجى إدخال البريد الإلكتروني وكلمة المرور.");
          return;
        }

        firebase.auth().signInWithEmailAndPassword(email, password)
          .then(userCredential => {
            alert("تم تسجيل الدخول بنجاح: " + userCredential.user.email);
            window.location.hash = "#index";
          })
          .catch(error => {
            alert("فشل تسجيل الدخول: " + error.message);
            console.error("Login Error:", error);
          });
      });
    }
  });
