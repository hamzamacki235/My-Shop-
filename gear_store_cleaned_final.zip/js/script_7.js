
  const firebaseConfig = {
    apiKey: "AIzaSyBGJ4yTFdFsgcs46fb4Uy96O2i8Az1kbus",
    authDomain: "electronicsmarket-95db5.firebaseapp.com",
    projectId: "electronicsmarket-95db5",
    storageBucket: "electronicsmarket-95db5.firebasestorage.app",
    messagingSenderId: "559298034101",
    appId: "1:559298034101:web:df162b5a24bf974ede01fc",
    measurementId: "G-G0G9ZHL5Z3"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const db = firebase.database();
