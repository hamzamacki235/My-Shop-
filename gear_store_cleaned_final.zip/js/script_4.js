
  
  window.addEventListener("DOMContentLoaded", () => {
    /* Showing by default */
  });
