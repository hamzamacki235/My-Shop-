
document.addEventListener("DOMContentLoaded", () => {
  const allowedAdmins = [
    "walmacki235@gmail.com",
    "hamzamacki235@gmail.com",
    "hamza2maki235@gmail.com"
  ];

  firebase.auth().onAuthStateChanged(user => {
    if (!user) {
      redirectToHome();
      return;
    }

    const isAdmin = allowedAdmins.includes(user.email);
    if (!isAdmin) {
      alert("أنت غير مصرح لك بالدخول إلى لوحة الإدارة.");
      redirectToHome();
    } else {
      const badge = document.getElementById("io-badge");
      if (badge) badge.style.display = "block";
      const welcome = document.getElementById("admin-welcome");
      if (welcome) welcome.style.display = "block";
    }
  });

  function redirectToHome() {
    const adminSection = document.getElementById("admin");
    const productBox = document.getElementById("add-product-box");
    const productsSection = document.getElementById("products");
    if (adminSection) adminSection.style.display = "none";
    if (productBox) productBox.style.display = "none";
    if (productsSection) productsSection.style.display = "none";
    window.location.hash = "#index";
  }
});
