
function addProduct() {
  const name = document.getElementById("name").value;
  const desc = document.getElementById("desc").value;
  const price = document.getElementById("price").value;
  const imageFile = document.getElementById("image").files[0];

  if (editingId) {
    db.collection("products").doc(editingId).update({
      name, desc, price: parseFloat(price)
    }).then(() => {
      alert("تم تحديث المنتج");
      editingId = null;
      loadProducts();
    });
    resetForm();
  } else if (imageFile) {
    const ref = firebase.storage().ref('product_images/' + Date.now() + '_' + imageFile.name);
    ref.put(imageFile).then(snapshot => snapshot.ref.getDownloadURL()).then(url => {
      db.collection("products").add({
        name,
        desc,
        price: parseFloat(price),
        image: url,
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
      }).then(() => {
        alert("تم حفظ المنتج مع الصورة");
        loadProducts();
      });
    });
    resetForm();
  } else {
    alert("الرجاء اختيار صورة للمنتج.");
  }
}
