
function adminLogin() {
  const enteredPass = document.getElementById("admin-pass").value;
  firebase.firestore().collection("settings").doc("admin").get().then(doc => {
    if (doc.exists && doc.data().password === enteredPass) {
      document.getElementById("payments").style.display = "block";
      alert("تم الدخول كمسؤول");
    } else {
      alert("كلمة مرور غير صحيحة");
    }
  }).catch(err => {
    console.error("فشل التحقق من كلمة المرور", err);
    alert("حدث خطأ أثناء التحقق");
  });
}
