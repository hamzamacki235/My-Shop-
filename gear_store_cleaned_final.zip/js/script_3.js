
  window.addEventListener("DOMContentLoaded", () => {
    openModal('loginModal');
  });
