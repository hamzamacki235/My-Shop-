
function loginWithFacebook() {
  const provider = new firebase.auth.FacebookAuthProvider();
  firebase.auth().signInWithPopup(provider)
    .then((result) => {
      const user = result.user;
      alert("مرحباً " + user.displayName);
    })
    .catch((error) => {
      console.error("فشل تسجيل الدخول:", error);
    });
}

