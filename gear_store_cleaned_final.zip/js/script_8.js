
  function logoutUser() {
    firebase.auth().signOut().then(() => {
      alert("تم تسجيل الخروج");
      location.reload();
    }).catch((error) => {
      console.error("فشل تسجيل الخروج", error);
    });
  }

