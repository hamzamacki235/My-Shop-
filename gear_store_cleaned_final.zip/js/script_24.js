
document.addEventListener("DOMContentLoaded", () => {
  
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("product-form");
  const logoutBtn = document.getElementById("logout-btn");
  if (form) {
    form.style.display = "block";
    if (logoutBtn) logoutBtn.style.display = "inline-block";
  }
});


function logoutUser() {
  firebase.auth().signOut().then(() => {
    alert("تم تسجيل الخروج");
    location.reload();
  });
}
