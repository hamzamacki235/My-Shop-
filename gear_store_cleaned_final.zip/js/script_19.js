
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
  import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
  import { getAuth, GoogleAuthProvider, FacebookAuthProvider, signInWithPopup } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-analytics.js";

  const firebaseConfig = {
    apiKey: "AIzaSyBGJ4yTFdFsgcs46fb4Uy96O2i8Az1kbus",
    authDomain: "electronicsmarket-95db5.firebaseapp.com",
    projectId: "electronicsmarket-95db5",
    storageBucket: "electronicsmarket-95db5.firebasestorage.app",
    messagingSenderId: "559298034101",
    appId: "1:559298034101:web:e38d0d1181a6e8ebde01fc",
    measurementId: "G-Z5MGPWT6CN"
  };

  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);
  const auth = getAuth(app);
  const analytics = getAnalytics(app);

  window.firebase = {
    firestore: db,
    auth: auth,
    GoogleAuthProvider,
    FacebookAuthProvider,
    signInWithPopup
  };
