
  document.addEventListener("DOMContentLoaded", () => {
    const registerForm = document.querySelector('#register form');
    if (registerForm) {
      registerForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const email = registerForm.querySelector('input[type="email"]').value.trim();
        const password = registerForm.querySelector('input[type="password"]').value;

        if (!email || !password) {
          alert("جميع الحقول مطلوبة.");
          return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          alert("البريد الإلكتروني غير صالح.");
          return;
        }

        if (password.length < 6) {
          alert("كلمة المرور يجب أن تكون 6 أحرف على الأقل.");
          return;
        }

        firebase.auth().createUserWithEmailAndPassword(email, password)
          .then(userCredential => {
            alert("تم إنشاء الحساب بنجاح: " + userCredential.user.email);
            window.location.hash = "#index";
          })
          .catch(error => {
            alert("فشل إنشاء الحساب: " + error.message);
            console.error("Register Error:", error);
          });
      });
    }
  });
