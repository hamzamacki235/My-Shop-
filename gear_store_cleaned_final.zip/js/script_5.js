
  let isGuest = false;

  function continueAsGuest() {
    document.getElementById("welcome-screen").style.display = "none";
    document.getElementById("guest-banner").style.display = "block";
    document.body.style.overflow = "auto";
    isGuest = true;
  }

  // Override addToCart and openRatingModal if user is guest
  window.addToCart = function(product) {
    if (isGuest) {
      alert("يجب تسجيل الدخول لإضافة المنتج إلى العربة.");
      return;
    }
    const existingItem = cart.find(item => item.id === product.id);
    if (existingItem) {
      if (confirm("هذا المنتج موجود بالفعل في العربة. هل تريد إضافة كمية أخرى؟")) {
        cart.push(product);
      }
    } else {
      cart.push(product);
    }
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart();
    alert("تمت إضافة المنتج إلى العربة");
  };

  window.openRatingModal = function(productId) {
    if (isGuest) {
      alert("يجب تسجيل الدخول لتقييم المنتج.");
      return;
    }
    document.getElementById("rating-product-id").value = productId;
    openModal("ratingModal");
  };
