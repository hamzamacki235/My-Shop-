
firebase.auth().onAuthStateChanged(user => {
  if (!user) return;
  const isAdmin = user.email === "walmacki235@gmail.com"; // عدل البريد لو لزم
  if (isAdmin) {
    const badge = document.getElementById("io-badge");
    
    if (badge) badge.style.display = "block";
    const welcome = document.getElementById("admin-welcome");
    if (welcome) welcome.style.display = "block";
    
  }
});
