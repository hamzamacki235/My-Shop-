
function playSwitchSound() {
  const audio = new Audio("https://cdn.pixabay.com/audio/2022/03/15/audio_bff1cde7a4.mp3");
  audio.play();
}

function showConfirmToast(msg) {
  const toast = document.getElementById("confirm-toast");
  toast.textContent = msg;
  toast.style.display = "block";
  setTimeout(() => {
    toast.style.display = "none";
  }, 2500);
}

function applySavedSettings() {
  const lang = localStorage.getItem("lang") || "ar";
  const dark = localStorage.getItem("dark") === "true";

  isArabic = lang === "ar";
  document.body.dir = isArabic ? "rtl" : "ltr";
  document.querySelectorAll('[data-ar]').forEach(el => {
    el.innerText = isArabic ? el.dataset.ar : el.dataset.en;
  });

  if (dark) {
    document.body.classList.add("dark-mode");
  }
}

function toggleLang() {
  isArabic = !isArabic;
  document.body.dir = isArabic ? "rtl" : "ltr";
  document.querySelectorAll('[data-ar]').forEach(el => {
    el.innerText = isArabic ? el.dataset.ar : el.dataset.en;
  });
  localStorage.setItem("lang", isArabic ? "ar" : "en");
  playSwitchSound();
  showConfirmToast("تم تغيير اللغة");
}

function toggleDarkMode() {
  const isDark = document.body.classList.toggle("dark-mode");
  localStorage.setItem("dark", isDark);
  playSwitchSound();
  showConfirmToast(isDark ? "تم تفعيل الوضع الليلي" : "تم إيقاف الوضع الليلي");
}

function resetSettings() {
  document.body.classList.remove("dark-mode");
  isArabic = true;
  document.body.dir = "rtl";
  document.querySelectorAll('[data-ar]').forEach(el => {
    el.innerText = el.dataset.ar;
  });
  localStorage.removeItem("lang");
  localStorage.removeItem("dark");
  playSwitchSound();
  showConfirmToast("تمت إعادة الإعدادات");
}

document.addEventListener("DOMContentLoaded", applySavedSettings);
