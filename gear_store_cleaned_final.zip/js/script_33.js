
function resetSettings() {
  document.body.classList.remove("dark-mode");
  isArabic = true;
  document.body.dir = "rtl";
  document.querySelectorAll('[data-ar]').forEach(el => {
    el.innerText = el.dataset.ar;
  });
}
