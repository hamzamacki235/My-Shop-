
  function submitPayment() {
    const name = document.querySelector('#checkout input[placeholder="الاسم"]').value;
    const card = document.querySelector('#checkout input[placeholder="رقم البطاقة"]').value;
    const notify = document.querySelector('#checkout input[placeholder="0920xxxxxxx"]').value;

    if (!name || !card || !notify) {
      alert("يرجى تعبئة جميع الحقول");
      return;
    }

    firebase.firestore().collection("payments").add({
      name, card, notify, createdAt: new Date()
    }).then(() => {
      alert("تم إرسال بيانات الدفع بنجاح");
    }).catch(err => {
      alert("حدث خطأ أثناء الحفظ");
      console.error(err);
    });
  }
