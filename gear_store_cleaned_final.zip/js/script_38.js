
  function toggleAddProduct() {
    const box = document.getElementById("add-product-box");
    if (box) {
      const isVisible = box.style.display === "block";
      box.style.display = isVisible ? "none" : "block";
      if (!isVisible) box.scrollIntoView({ behavior: "smooth" });
    }
  }
