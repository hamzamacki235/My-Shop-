
let lastProductId = null;
let knownProductIds = new Set();
let previousProductStates = new Map();

function playNotificationSound(type) {
  const url = type === "add"
    ? "https://cdn.pixabay.com/audio/2023/03/29/audio_b9f5b00dd6.mp3"
    : type === "delete"
    ? "https://cdn.pixabay.com/audio/2022/03/15/audio_a84130e8f7.mp3"
    : "https://cdn.pixabay.com/audio/2022/03/17/audio_7f155312b2.mp3";

  const audio = new Audio(url);
  audio.play();
}

function showToast(message, type = "info") {
  const toast = document.getElementById("toast");
  const toastMsg = document.getElementById("toast-msg");
  const toastImg = document.getElementById("toast-icon-img");

  toastMsg.textContent = message;
  toastImg.src = type === "add"
    ? "https://cdn-icons-png.flaticon.com/512/845/845646.png"
    : type === "delete"
    ? "https://cdn-icons-png.flaticon.com/512/1828/1828843.png"
    : type === "edit"
    ? "https://cdn-icons-png.flaticon.com/512/1250/1250615.png"
    : "https://cdn-icons-png.flaticon.com/512/190/190411.png";

  toast.className = "show";
  setTimeout(() => { hideToast(); }, 6000);
}

function hideToast() {
  const toast = document.getElementById("toast");
  toast.className = toast.className.replace("show", "");
}

function isProductChanged(id, newData) {
  const oldData = previousProductStates.get(id);
  if (!oldData) return false;
  return (
    oldData.name !== newData.name ||
    oldData.desc !== newData.desc ||
    oldData.price !== newData.price ||
    oldData.image !== newData.image
  );
}

function displayUploadedProducts() {
  const container = document.getElementById("uploaded-products");
  firebase.firestore().collection("products").orderBy("timestamp", "desc").limit(10).get().then(snapshot => {
    const newItems = [];
    const currentIds = new Set();
    const editedItems = [];

    container.innerHTML = "";
    snapshot.forEach((doc, index) => {
      const p = doc.data();
      currentIds.add(doc.id);

      if (!knownProductIds.has(doc.id)) {
        newItems.push(doc.id);
      } else if (isProductChanged(doc.id, p)) {
        editedItems.push(doc.id);
      }

      knownProductIds.add(doc.id);
      previousProductStates.set(doc.id, { ...p });

      const card = document.createElement("div");
      card.className = "product";
      card.innerHTML = `
        ${p.image ? '<img src="${p.image}" style="max-width:100px;"><br>' : ''}
        <strong>${p.name}</strong><br>
        ${p.desc}<br>
        السعر: ${p.price} ريال
      `;
      container.appendChild(card);
    });

    const deletedItems = [...previousProductStates.keys()].filter(id => !currentIds.has(id));
    previousProductStates = new Map([...previousProductStates].filter(([id]) => currentIds.has(id)));

    if (newItems.length > 0 && lastProductId !== null) {
      playNotificationSound("add");
      showToast(`تمت إضافة ${newItems.length} منتج${newItems.length > 1 ? 'ات' : ''} جديد${newItems.length > 1 ? 'ة' : ''}!`, "add");
      logActivity(`إضافة ${newItems.length} منتج جديد`);
    }

    if (deletedItems.length > 0) {
      playNotificationSound("delete");
      showToast(`تم حذف ${deletedItems.length} منتج${deletedItems.length > 1 ? 'ات' : ''}.`, "delete");
      logActivity(`حذف ${deletedItems.length} منتج`);
    }

    if (editedItems.length > 0) {
      playNotificationSound("edit");
      showToast(`تم تعديل ${editedItems.length} منتج${editedItems.length > 1 ? 'ات' : ''}.`, "edit");
      logActivity(`تعديل ${editedItems.length} منتج`);
    }

    if (snapshot.docs.length > 0) {
      lastProductId = snapshot.docs[0].id;
    }
  }).catch(err => {
    container.innerHTML = "<p>حدث خطأ أثناء تحميل المنتجات</p>";
    console.error(err);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  displayUploadedProducts();
  setInterval(displayUploadedProducts, 60000);
});
