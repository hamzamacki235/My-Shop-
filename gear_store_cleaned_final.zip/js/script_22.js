
function loadSortedProducts() {
  const productsList = document.getElementById("products-list");
  const sortValue = document.getElementById("sort-products").value;
  let query = firebase.firestore().collection("products");

  if (sortValue === "timestamp_desc") {
    query = query.orderBy("timestamp", "desc");
  } else if (sortValue === "price_asc") {
    query = query.orderBy("price", "asc");
  } else if (sortValue === "price_desc") {
    query = query.orderBy("price", "desc");
  }

  productsList.innerHTML = "<p>...جاري تحميل المنتجات</p>";

  query.get().then(snapshot => {
    productsList.innerHTML = "";
    snapshot.forEach(doc => {
      const p = doc.data();
      const card = document.createElement("div");
      card.className = "product";
      card.innerHTML = `
        ${p.image ? '<img src="' + p.image + '" style="max-width:100px;"><br>' : ''}
        <strong>${p.name}</strong><br>${p.desc}<br>السعر: ${p.price} ريال
      `;
      productsList.appendChild(card);
    });
  });
}
