
    import {
      initializeApp
    } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
    import {
      getAnalytics
    } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-analytics.js";
    import {
      getAuth, onAuthStateChanged, signOut,
      createUserWithEmailAndPassword, signInWithEmailAndPassword,
      GoogleAuthProvider, FacebookAuthProvider, signInWithPopup
    } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
    import {
      getFirestore, collection, addDoc, getDocs, serverTimestamp,
      doc, setDoc, getDoc, updateDoc, arrayUnion, deleteDoc, query, where
    } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

    /* ---- إعداد Firebase ---- */
    const firebaseConfig = {
      apiKey:            "AIzaSyAB7IuZDg99I0NJcTzOicvjtz4Lxg448ms",
      authDomain:        "gearstore-51108.firebaseapp.com",
      projectId:         "gearstore-51108",
      storageBucket:     "gearstore-51108.appspot.com",
      messagingSenderId: "397057376368",
      appId:             "1:397057376368:web:646d75263ed930a3f2b4b5",
      measurementId:     "G-Q16MW55P0W"
    };
    const app      = initializeApp(firebaseConfig);
    const analytics= getAnalytics(app);
    const auth     = getAuth(app);
    const db       = getFirestore(app);

    // ✅ تحقق من حالة تسجيل الدخول
    onAuthStateChanged(auth, (user) => {
      if (!user) {
        window.location.href = "login.html"; // المستخدم غير مسجل => تحويل تلقائي
      }
    });

    /* ---- مزودي تسجيل الدخول ---- */
    const googleProvider   = new GoogleAuthProvider();
    googleProvider.setCustomParameters({ prompt: "select_account" });
    const facebookProvider = new FacebookAuthProvider();

    /* ---- حالة العربة ---- */
    let cart = JSON.parse(localStorage.getItem("cart") || "[]");
    let allProducts = [];

    /* ---- وظائف القائمة المتنقلة ---- */
    function toggleMobileMenu() {
      const nav = document.getElementById('navbar-links');
      nav.classList.toggle('show');
    }

    document.querySelectorAll('.topnav a').forEach(link => {
      link.addEventListener('click', () => {
        document.getElementById('navbar-links').classList.remove('show');
      });
    });

    /* ---- وظائف البحث والتصفية ---- */
    function searchProducts() {
      const searchTerm = document.getElementById('search-input').value.toLowerCase();
      const filtered = allProducts.filter(product => 
        product.name.toLowerCase().includes(searchTerm) || 
        product.desc.toLowerCase().includes(searchTerm)
      );
      renderProducts(filtered);
    }

    function filterProducts() {
      const category = document.getElementById('category-filter').value;
      if (!category) {
        renderProducts(allProducts);
        return;
      }
      const filtered = allProducts.filter(product => product.category === category);
      renderProducts(filtered);
    }

    function renderProducts(products) {
      const container = document.getElementById("product-list");
      container.innerHTML = "";
      
      if (products.length === 0) {
        container.innerHTML = '<div class="empty">لا توجد منتجات مطابقة للبحث</div>';
        return;
      }
      
      products.forEach(product => {
        const card = document.createElement("div");
        card.className = "product";
        
        // حساب متوسط التقييم
        const avgRating = product.ratings && product.ratings.length > 0 ? 
          (product.ratings.reduce((sum, r) => sum + r.rating, 0) / product.ratings.length).toFixed(1) : 
          0;
        
        card.innerHTML = `
          <img src="${product.image}" class="product-image" alt="${product.name}">
          <h3>${product.name}</h3>
          <p>${product.desc}</p>
          <strong>السعر: ${product.price} ريال</strong>
          <div class="average-rating">${'★'.repeat(Math.round(avgRating))} (${avgRating})</div>
        `;
        
        const btnCart = document.createElement("button");
        btnCart.textContent = "🛒 أضف للعربة";
        btnCart.addEventListener("click", () => addToCart(product));
        card.appendChild(btnCart);
        
        const btnRate = document.createElement("button");
        btnRate.textContent = "⭐ قيم المنتج";
        btnRate.style.marginTop = "5px";
        btnRate.style.background = "#ffc107";
        btnRate.addEventListener("click", () => openRatingModal(product.id));
        card.appendChild(btnRate);
        
        // إضافة زر حذف للمسؤولين
        if (isAdmin) {
          const btnDelete = document.createElement("button");
          btnDelete.textContent = "🗑️ حذف المنتج";
          btnDelete.style.marginTop = "5px";
          btnDelete.style.background = "#dc3545";
          btnDelete.addEventListener("click", () => deleteProduct(product.id));
          card.appendChild(btnDelete);
        }
        
        container.appendChild(card);
      });
    }

    /* ---- وظيفة فتح مودال التقييم ---- */
    function openRatingModal(productId) {
      if (!auth.currentUser) {
        alert("يرجى تسجيل الدخول لتقييم المنتج");
        openModal("loginModal");
        return;
      }
      document.getElementById("rating-product-id").value = productId;
      openModal("ratingModal");
    }

    /* ---- وظيفة إرسال التقييم ---- */
    async function submitRating(e) {
      e.preventDefault();
      const productId = document.getElementById("rating-product-id").value;
      const rating = document.querySelector('input[name="rating"]:checked').value;
      const comment = document.getElementById("rating-comment").value;
      const userId = auth.currentUser.uid;
      
      try {
        const productRef = doc(db, "products", productId);
        await updateDoc(productRef, {
          ratings: arrayUnion({
            userId,
            rating: parseInt(rating),
            comment,
            timestamp: serverTimestamp()
          })
        });
        
        alert("شكراً لتقييمك المنتج!");
        closeModal("ratingModal");
        loadProducts();
      } catch (error) {
        alert("حدث خطأ أثناء إرسال التقييم: " + error.message);
      }
    }

    /* ---- وظائف العربة ---- */
    function renderCart() {
      const cartContainer = document.getElementById("cart-list");
      cartContainer.innerHTML = cart.length ? "" : "لا توجد منتجات في العربة.";
      cart.forEach((p, index) => {
        const div = document.createElement("div");
        div.className = "product";
        div.innerHTML = `
          <h3>${p.name}</h3>
          <strong>${p.price} ريال</strong><br>
          <button onclick="removeFromCart(${index})" style="background:#dc3545">❌ حذف</button>
        `;
        cartContainer.appendChild(div);
      });
      updateCartBadge();
    }

    function updateCartBadge() {
      const badge = document.getElementById("cart-badge");
      if (badge) {
        badge.textContent = cart.length > 0 ? cart.length : "";
        badge.style.display = cart.length > 0 ? "inline-block" : "none";
      }
    }

    window.removeFromCart = function(index) {
      cart.splice(index, 1);
      localStorage.setItem("cart", JSON.stringify(cart));
      renderCart();
    };

    /* ---- إتمام الطلب ---- */
    async function checkout() {
      if (!auth.currentUser) {
        alert("يرجى تسجيل الدخول قبل تأكيد الطلب");
        openModal("loginModal");
        return;
      }
      if (!cart.length) return alert("عربة التسوق فارغة!");
      
      try {
        await addDoc(collection(db, "orders"), {
          userId: auth.currentUser.uid,
          items: cart,
          createdAt: serverTimestamp(),
          status: "قيد المعالجة",
          customerName: auth.currentUser.displayName || "مستخدم غير معروف",
          customerEmail: auth.currentUser.email
        });
        alert("تم إرسال الطلب بنجاح!");
        cart = [];
        localStorage.removeItem("cart");
        renderCart();
        loadOrders();
        loadAdminOrders(); // تحديث لوحة التحكم إذا كانت مفتوحة
      } catch (error) {
        alert("حدث خطأ أثناء إرسال الطلب: " + error.message);
      }
    }

    /* ---- تحميل الطلبات الخاصة بالمستخدم ---- */
    async function loadOrders() {
      const container = document.getElementById("order-list");
      container.innerHTML = "";
      if (!auth.currentUser) {
        container.innerHTML = "يرجى تسجيل الدخول لعرض سجل الطلبات.";
        return;
      }
      
      try {
        const q = query(collection(db, "orders"), where("userId", "==", auth.currentUser.uid));
        const querySnapshot = await getDocs(q);
        
        if (querySnapshot.empty) {
          container.innerHTML = "لا يوجد طلبات لهذا المستخدم.";
          return;
        }
        
        querySnapshot.forEach(doc => {
          const order = doc.data();
          const card = document.createElement("div");
          card.className = "product";
          const dateStr = order.createdAt ? order.createdAt.toDate().toLocaleString() : "تاريخ غير متوفر";
          card.innerHTML = `<h4>طلب بتاريخ: ${dateStr} (${order.status})</h4>`;
          order.items.forEach(p => {
            card.innerHTML += `<p>📦 ${p.name} - ${p.price} ريال</p>`;
          });
          container.appendChild(card);
        });
      } catch (error) {
        container.innerHTML = "حدث خطأ أثناء تحميل الطلبات.";
        console.error("Error loading orders:", error);
      }
    }

    /* ---- تحميل المنتجات ---- */
    async function loadProducts() {
      const container = document.getElementById("product-list");
      container.innerHTML = '<div class="loading-spinner"><div class="spinner"></div><p>جاري تحميل المنتجات...</p></div>';
      
      try {
        const querySnapshot = await getDocs(collection(db, "products"));
        allProducts = [];
        querySnapshot.forEach(doc => {
          allProducts.push({ id: doc.id, ...doc.data() });
        });
        
        if (allProducts.length === 0) {
          container.innerHTML = '<div class="empty">لا توجد منتجات متاحة حالياً.</div>';
          return;
        }
        
        renderProducts(allProducts);
        if (isAdmin) loadAdminProducts(); // تحميل قائمة المنتجات للوحة التحكم
      } catch (error) {
        container.innerHTML = '<div class="error">حدث خطأ أثناء تحميل المنتجات.</div>';
        console.error("Error loading products:", error);
      }
    }

    /* ---- إضافة منتج جديد (للمسؤولين) ---- */
    window.addProduct = async function(e) {
      e.preventDefault();
      
      const name = document.getElementById("product-name").value;
      const desc = document.getElementById("product-desc").value;
      const price = parseFloat(document.getElementById("product-price").value);
      const category = document.getElementById("product-category").value;
      const image = document.getElementById("product-image").value;
      
      if (!name || !desc || isNaN(price) || !category || !image) {
        alert("يرجى ملء جميع الحقول بشكل صحيح");
        return;
      }
      
      try {
        await addDoc(collection(db, "products"), {
          name,
          desc,
          price,
          category,
          image,
          createdAt: serverTimestamp(),
          ratings: []
        });
        
        document.getElementById("add-product-form").reset();
        alert("تمت إضافة المنتج بنجاح!");
        loadProducts();
      } catch (error) {
        alert("حدث خطأ أثناء إضافة المنتج: " + error.message);
      }
    };

    /* ---- حذف منتج (للمسؤولين) ---- */
    window.deleteProduct = async function(productId) {
      if (!confirm("هل أنت متأكد من حذف هذا المنتج؟ لا يمكن التراجع عن هذه العملية.")) return;
      
      try {
        await deleteDoc(doc(db, "products", productId));
        alert("تم حذف المنتج بنجاح");
        loadProducts();
      } catch (error) {
        alert("حدث خطأ أثناء حذف المنتج: " + error.message);
      }
    };

    /* ---- تحميل الطلبات للمسؤولين ---- */
    async function loadAdminOrders() {
      const container = document.getElementById("admin-orders-list");
      if (!container) return;
      container.innerHTML = "";
      
      try {
        const querySnapshot = await getDocs(collection(db, "orders"));
        
        if (querySnapshot.empty) {
          container.innerHTML = "<p>لا توجد طلبات حتى الآن.</p>";
          return;
        }
        
        querySnapshot.forEach(doc => {
          const order = doc.data();
          const card = document.createElement("div");
          card.className = "product";
          const dateStr = order.createdAt ? order.createdAt.toDate().toLocaleString() : "تاريخ غير متوفر";
          
          card.innerHTML = `
            <h4>طلب #${doc.id}</h4>
            <p><strong>العميل:</strong> ${order.customerName} (${order.customerEmail})</p>
            <p><strong>التاريخ:</strong> ${dateStr}</p>
            <p><strong>الحالة:</strong> ${order.status}</p>
            <div class="order-items">
              ${order.items.map(p => `<p>📦 ${p.name} - ${p.price} ريال</p>`).join("")}
            </div>
            <p><strong>المجموع:</strong> ${order.items.reduce((sum, item) => sum + item.price, 0)} ريال</p>
            <select id="status-${doc.id}" onchange="updateOrderStatus('${doc.id}', this.value)">
              <option value="قيد المعالجة" ${order.status === "قيد المعالجة" ? "selected" : ""}>قيد المعالجة</option>
              <option value="تم الشحن" ${order.status === "تم الشحن" ? "selected" : ""}>تم الشحن</option>
              <option value="مكتمل" ${order.status === "مكتمل" ? "selected" : ""}>مكتمل</option>
              <option value="ملغي" ${order.status === "ملغي" ? "selected" : ""}>ملغي</option>
            </select>
          `;
          
          container.appendChild(card);
        });
      } catch (error) {
        container.innerHTML = '<div class="error-message">حدث خطأ أثناء تحميل الطلبات</div>';
        console.error("Error loading admin orders:", error);
      }
    }

    /* ---- تحديث حالة الطلب (للمسؤولين) ---- */
    window.updateOrderStatus = async function(orderId, newStatus) {
      try {
        await updateDoc(doc(db, "orders", orderId), {
          status: newStatus
        });
        // لا حاجة لتحميل كل الطلبات مجدداً، يمكن تحديث الواجهة مباشرة
        document.querySelector(`#status-${orderId}`).value = newStatus;
      } catch (error) {
        alert("حدث خطأ أثناء تحديث حالة الطلب: " + error.message);
      }
    };

    /* ---- تحميل المنتجات للمسؤولين ---- */
    async function loadAdminProducts() {
      const container = document.getElementById("admin-products-list");
      if (!container) return;
      container.innerHTML = "";
      
      try {
        const querySnapshot = await getDocs(collection(db, "products"));
        
        if (querySnapshot.empty) {
          container.innerHTML = "<p>لا توجد منتجات حتى الآن.</p>";
          return;
        }
        
        querySnapshot.forEach(doc => {
          const product = doc.data();
          const card = document.createElement("div");
          card.className = "product";
          
          card.innerHTML = `
            <h4>${product.name}</h4>
            <img src="${product.image}" class="product-image" alt="${product.name}">
            <p>${product.desc}</p>
            <p><strong>السعر:</strong> ${product.price} ريال</p>
            <p><strong>الفئة:</strong> ${product.category}</p>
            <button onclick="deleteProduct('${doc.id}')" style="background:#dc3545">🗑️ حذف المنتج</button>
          `;
          
          container.appendChild(card);
        });
      } catch (error) {
        container.innerHTML = '<div class="error-message">حدث خطأ أثناء تحميل المنتجات</div>';
        console.error("Error loading admin products:", error);
      }
    }

    /* ---- فتح لوحة التحكم للمسؤولين ---- */
    window.openAdminPanel = function() {
      document.getElementById("admin-panel").classList.remove("hidden");
      document.getElementById("products").classList.add("hidden");
      document.getElementById("cart").classList.add("hidden");
      document.getElementById("orders").classList.add("hidden");
      document.getElementById("faq").classList.add("hidden");
      document.getElementById("contact").classList.add("hidden");
      document.getElementById("add").classList.add("hidden");
      
      loadAdminOrders();
      loadAdminProducts();
    };

    /* ---- إضافة منتج للعربة ---- */
    window.addToCart = function(product) {
      if (!auth.currentUser) {
        alert("يرجى تسجيل الدخول لإضافة المنتج إلى العربة.");
        openModal("loginModal");
        return;
      }
      
      const existingItem = cart.find(item => item.id === product.id);
      if (existingItem) {
        if (confirm("هذا المنتج موجود بالفعل في العربة. هل تريد إضافة كمية أخرى؟")) {
          cart.push(product);
        }
      } else {
        cart.push(product);
      }
      
      localStorage.setItem("cart", JSON.stringify(cart));
      renderCart();
      alert("تمت إضافة المنتج إلى العربة");
    };

    /* ---- تسجيل الدخول بالبريد ---- */
    window.loginUser = function(e) {
      e.preventDefault();
      const email = document.getElementById("login-email").value.trim();
      const password = document.getElementById("login-password").value;
      
      if (!email || !password) {
        alert("يرجى إدخال البريد الإلكتروني وكلمة المرور");
        return;
      }
      
      const btn = e.target.querySelector("button[type='submit']");
      const originalText = btn.textContent;
      btn.textContent = "جاري تسجيل الدخول...";
      btn.disabled = true;
      
      signInWithEmailAndPassword(auth, email, password)
        .then(() => {
          alert("تم تسجيل الدخول بنجاح");
          closeModal("loginModal");
          renderCart();
          loadOrders();
        })
        .catch(err => {
          let message = "حدث خطأ أثناء تسجيل الدخول";
          if (err.code === "auth/invalid-credential") {
            message = "البريد الإلكتروني أو كلمة المرور غير صحيحة";
          }
          alert(message);
        })
        .finally(() => {
          btn.textContent = originalText;
          btn.disabled = false;
        });
    };

    /* ---- تسجيل الدخول بجوجل ---- */
    window.signInWithGoogle = function() {
      signInWithPopup(auth, googleProvider)
        .then(() => {
          alert("تم تسجيل الدخول بحساب Google");
          closeModal("loginModal");
          renderCart();
          loadOrders();
        })
        .catch(err => alert("خطأ: " + err.message));
    };

    /* ---- تسجيل الدخول بفيسبوك ---- */
    window.signInWithFacebook = function() {
      signInWithPopup(auth, facebookProvider)
        .then(() => {
          alert("تم تسجيل الدخول بحساب Facebook");
          closeModal("loginModal");
          renderCart();
          loadOrders();
        })
        .catch(err => {
          if (err.code === "auth/account-exists-with-different-credential") {
            alert("هذا البريد مرتبط بطريقة تسجيل مختلفة. جرّب تسجيل الدخول بالطريقة الأخرى.");
          } else {
            alert("خطأ: " + err.message);
          }
        });
    };

    /* ---- إنشاء حساب بالبريد ---- */
    window.registerUser = function(e) {
      e.preventDefault();
      const email = document.getElementById("register-email").value.trim();
      const password = document.getElementById("register-password").value;
      
      if (!email || !password) {
        alert("يرجى إدخال البريد الإلكتروني وكلمة المرور");
        return;
      }
      
      const btn = e.target.querySelector("button[type='submit']");
      const originalText = btn.textContent;
      btn.textContent = "جاري إنشاء الحساب...";
      btn.disabled = true;
      
      createUserWithEmailAndPassword(auth, email, password)
        .then(() => {
          alert("تم إنشاء الحساب بنجاح");
          closeModal("registerModal");
        })
        .catch(err => alert("خطأ: " + err.message))
        .finally(() => {
          btn.textContent = originalText;
          btn.disabled = false;
        });
    };

    /* ---- تسجيل الخروج ---- */
    window.logoutUser = function() {
      if (confirm("هل أنت متأكد من تسجيل الخروج؟")) {
        signOut(auth).then(() => {
          alert("تم تسجيل الخروج");
          renderCart();
          loadOrders();
        }).catch(err => alert("حدث خطأ أثناء تسجيل الخروج: " + err.message));
      }
    };

    /* ---- مراقبة حالة المستخدم ---- */
    let isAdmin = false;
    onAuthStateChanged(auth, (user) => {
      const loginLink = document.getElementById("loginLink");
      const registerLink = document.getElementById("registerLink");
      const logoutLink = document.getElementById("logoutLink");
      const adminLink = document.getElementById("adminLink");
      const addProductLink = document.getElementById("addProductLink");
      
      if (user) {
        loginLink.style.display = "none";
        registerLink.style.display = "none";
        logoutLink.style.display = "inline-block";
        
        // التحقق من صلاحيات المسؤول
        getDoc(doc(db, "users", user.uid)).then(docSnap => {
          if (docSnap.exists() && docSnap.data().isAdmin) {
            isAdmin = true;
            adminLink.classList.remove("hidden");
            addProductLink.classList.remove("hidden");
          } else {
            isAdmin = false;
            adminLink.classList.add("hidden");
            addProductLink.classList.add("hidden");
            document.getElementById("admin-panel").classList.add("hidden");
          }
        });
        
        // عرض اسم المستخدم
        const greeting = document.getElementById("user-greeting");
        if (greeting) {
          greeting.textContent = `مرحباً، ${user.displayName || user.email.split('@')[0]}`;
        }
      } else {
        loginLink.style.display = "inline-block";
        registerLink.style.display = "inline-block";
        logoutLink.style.display = "none";
        adminLink.classList.add("hidden");
        addProductLink.classList.add("hidden");
      }
    });

    /* ---- تحميل أولي ---- */
    window.addEventListener("DOMContentLoaded", () => {
      renderCart();
      loadProducts();
      loadOrders();
      
      // إدارة عرض الأقسام
      document.querySelectorAll('.topnav a').forEach(link => {
        link.addEventListener('click', function(e) {
          if (this.getAttribute('href').startsWith('#')) {
            e.preventDefault();
            const sectionId = this.getAttribute('href').substring(1);
            document.querySelectorAll('.main-section').forEach(section => {
              section.classList.add('hidden');
            });
            document.getElementById(sectionId).classList.remove('hidden');
          }
        });
      });
    });
  