
  let isArabic = true;

  function toggleLang() {
    isArabic = !isArabic;
    document.body.dir = isArabic ? "rtl" : "ltr";
    document.querySelectorAll('[data-ar]').forEach(el => {
      el.innerText = isArabic ? el.dataset.ar : el.dataset.en;
    });
  }

  
function deleteProduct(id) {
  if (confirm("هل أنت متأكد من حذف المنتج؟")) {
    db.ref('products/' + id).remove().then(loadProducts);
  }
}

function editProduct(id) {
  db.ref('products/' + id).once('value', snapshot => {
    const p = snapshot.val();
    document.getElementById('product-name').value = p.name;
    document.getElementById('product-description').value = p.description;
    document.getElementById('product-price').value = p.price;
    document.getElementById('product-image').value = p.image;
    document.getElementById('add-product-form').onsubmit = function(e) {
      e.preventDefault();
      const updated = {
        name: document.getElementById('product-name').value,
        description: document.getElementById('product-description').value,
        price: document.getElementById('product-price').value,
        image: document.getElementById('product-image').value
      };
      db.ref('products/' + id).set(updated).then(() => {
        loadProducts();
        this.reset();
        this.onsubmit = defaultAddHandler;
      });
    };
  });
}


const defaultAddHandler = function(e) {
  e.preventDefault();
  const name = document.getElementById('product-name').value;
  const description = document.getElementById('product-description').value;
  const price = document.getElementById('product-price').value;
  const image = document.getElementById('product-image').value;
  const newProduct = { name, description, price, image };

  if (navigator.onLine) {
    db.ref('products').push(newProduct, loadProducts);
  } else {
    let offlineList = JSON.parse(localStorage.getItem("offline_products") || "[]");
    offlineList.push(newProduct);
    localStorage.setItem("offline_products", JSON.stringify(offlineList));
    alert("تم حفظ المنتج مؤقتًا بدون إنترنت.");
    loadProducts();
  }
  e.target.reset();
};

  db.ref('products').push(newProduct, loadProducts);
  this.reset();
};

document.addEventListener("DOMContentLoaded", () => {
  loadProducts();
  const form = document.getElementById('add-product-form');
  if (form) {
    form.onsubmit = defaultAddHandler;
  }
});


document.addEventListener("DOMContentLoaded", () => {
  const lang = navigator.language || navigator.userLanguage;
  if (lang.startsWith("en")) {
    isArabic = false;
    toggleLang();
  }
});
