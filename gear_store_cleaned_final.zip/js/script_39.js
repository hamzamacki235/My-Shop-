
document.addEventListener("DOMContentLoaded", () => {
  const sections = document.querySelectorAll("section");
  sections.forEach(section => {
    section.style.display = section.id === "login" ? "block" : "none";
  });
});
