
function addProduct() {
  const name = document.getElementById("name").value;
  const desc = document.getElementById("desc").value;
  const price = document.getElementById("price").value;
  const imageFile = document.getElementById("image").files[0];
  const user = firebase.auth().currentUser;

  if (!user) {
    alert("يجب تسجيل الدخول");
    return;
  }

  if (imageFile) {
    const ref = firebase.storage().ref('product_images/' + Date.now() + '_' + imageFile.name);
    ref.put(imageFile).then(snapshot => snapshot.ref.getDownloadURL()).then(url => {
      firebase.firestore().collection("products").add({
        name,
        desc,
        price: parseFloat(price),
        image: url,
        timestamp: firebase.firestore.FieldValue.serverTimestamp(),
        userId: user.uid,
        userEmail: user.email
      }).then(() => {
        alert("تم حفظ المنتج");
        loadSortedProducts();
      });
    });
    resetForm();
  } else {
    alert("الرجاء اختيار صورة للمنتج.");
  }
}
