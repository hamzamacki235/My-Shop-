
function logActivity(message) {
  const list = document.getElementById("activity-list");
  const li = document.createElement("li");
  li.textContent = `${new Date().toLocaleTimeString()} - ${message}`;
  li.style.marginBottom = "8px";
  list.prepend(li); // latest on top
}
