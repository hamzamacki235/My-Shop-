
function loginWithGoogle() {
  const provider = new firebase.auth.GoogleAuthProvider();
  firebase.auth().signInWithPopup(provider).then(result => {
    alert("تم تسجيل الدخول عبر Google: " + result.user.displayName);
  }).catch(error => {
    alert("فشل تسجيل الدخول عبر Google");
    console.error(error);
  });
}

function loginWithFacebook() {
  const provider = new firebase.auth.FacebookAuthProvider();
  firebase.auth().signInWithPopup(provider).then(result => {
    alert("تم تسجيل الدخول عبر Facebook: " + result.user.displayName);
  }).catch(error => {
    alert("فشل تسجيل الدخول عبر Facebook");
    console.error(error);
  });
}
