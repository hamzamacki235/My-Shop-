
function loadCloudActivityLog() {
  const list = document.getElementById("cloud-activity-list");
  list.innerHTML = "<li>...تحميل السجل</li>";
  firebase.firestore().collection("activity_log").orderBy("timestamp", "desc").limit(20).get().then(snapshot => {
    list.innerHTML = "";
    snapshot.forEach(doc => {
      const data = doc.data();
      const li = document.createElement("li");
      const time = data.timestamp?.toDate().toLocaleString() || "بدون وقت";
      li.textContent = `${time} - (${data.userId}) ${data.message}`;
      li.style.marginBottom = "8px";
      list.appendChild(li);
    });
  }).catch(err => {
    list.innerHTML = "<li>حدث خطأ أثناء تحميل السجل</li>";
    console.error("Failed to load activity log:", err);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadCloudActivityLog();
});
