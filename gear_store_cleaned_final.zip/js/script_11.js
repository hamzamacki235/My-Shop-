
  function scrollToForm() {
    const form = document.getElementById("add-product-form");
    if (form) {
      form.scrollIntoView({ behavior: "smooth" });
    }
  }
